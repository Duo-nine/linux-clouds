#include <stdio.h>
#include <unistd.h>

int main()
{
    while(1)
    {
        printf("program is running...\n");
        sleep(1);
    }
    return 0;
}
